import { c as defineEventHandler, r as readBody, e as createError } from '../../_/nitro.mjs';
import fs from 'fs';
import path from 'path';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const index_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const storagePath = getStoragePath();
  try {
    fs.mkdirSync(path.dirname(storagePath), { recursive: true });
    fs.writeFileSync(storagePath, JSON.stringify(body.data, null, 2));
    return { success: true };
  } catch (error) {
    console.error("\u4FDD\u5B58\u5B58\u50A8\u6570\u636E\u5931\u8D25:", error);
    throw createError({
      statusCode: 500,
      statusMessage: "\u4FDD\u5B58\u5B58\u50A8\u6570\u636E\u5931\u8D25"
    });
  }
});
function getStoragePath() {
  return path.join(process.cwd(), "storage", "app_data.json");
}

export { index_post as default };
//# sourceMappingURL=index.post.mjs.map
