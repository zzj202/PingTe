import{d as e}from"./BREDHpJz.js";const o=e({__name:"index",setup(n){return(t,r)=>null}});export{o as default};
