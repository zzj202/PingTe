import { c as defineEventHandler, e as createError } from '../../_/nitro.mjs';
import fs from 'fs';
import path from 'path';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const index_get = defineEventHandler(async () => {
  const storagePath = getStoragePath();
  try {
    if (fs.existsSync(storagePath)) {
      const data = fs.readFileSync(storagePath, "utf-8");
      return JSON.parse(data);
    }
    return {};
  } catch (error) {
    console.error("\u8BFB\u53D6\u5B58\u50A8\u6570\u636E\u5931\u8D25:", error);
    throw createError({
      statusCode: 500,
      statusMessage: "\u8BFB\u53D6\u5B58\u50A8\u6570\u636E\u5931\u8D25"
    });
  }
});
function getStoragePath() {
  return path.join(process.cwd(), "storage", "app_data.json");
}

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
